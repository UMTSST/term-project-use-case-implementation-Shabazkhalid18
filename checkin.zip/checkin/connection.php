<?php
		$server="localhost";
		$unm="root";
		$pwd="";
		$db="hotel";
		$con=mysqli_connect($server,$unm,$pwd,$db);
?>
