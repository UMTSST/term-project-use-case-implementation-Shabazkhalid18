<html>
<head>
	<title>suite</title>
</head>
<body bgcolor="#fff2e5">
	<center><font color=purple size=6><a href=suite1.php>Suite</a></font></center>
	<img src="image/p01.jpg" height=360 width=735>
	<font color=purple size=3>
	<pre>                luxuriously furnished room having a sofa cum bed
		for an extra adult or child with wall to wall carpet.
		this rooms are attached with private balconies over looking the
		palm view garden.
	</font>
	</pre>
	<a href=accommodation.php>home</a>
</body>
</html>